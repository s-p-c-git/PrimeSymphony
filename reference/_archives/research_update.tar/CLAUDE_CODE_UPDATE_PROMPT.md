# Claude Code — Integrate Research Update into PrimeSymphony

This package contains new and updated research artefacts from a session that
extended the shifted-prime-tension work. Your job: integrate them into the repo
cleanly, verify the scripts run, and commit (with my approval before push).

## What's in this package

```
research/
├── PRIME_RESEARCH_CONTEXT.md      (UPDATED — standing premise + guardrails)
├── PRIME_RESEARCH_SYNTHESIS.md    (UPDATED — six-lens synthesis + ALL proven results)
├── tier1_deep_dives.py            (NEW — DD1 singular-series law, DD2 handedness theorem)
├── tier1_leftovers.py             (NEW — LO3 free-side dist, LO4 sum-to-twin check)
└── figures/
    ├── fig_newton_convergence.png (NEW — FFT-seeded Newton convergence, 10/10 to 1e-10)
    └── fig_classification_grid.png(NEW — T_k split/inert/empty grid, period-6 visible)
```

## Context: what changed in this session

1. **Two Tier-1 deep dives were COMPLETED and PROVEN:**
   - DD1: the tension-fraction law frac(spf(p+2)=q) = (1/(q-1))·∏_{3≤r<q}(r-2)/(r-1),
     a Hardy-Littlewood singular series, verified to <1% over 348,510 primes.
   - DD2: the Exactly-One-Maximum theorem — every isolated prime has spf=3 on
     EXACTLY one side, determined by p mod 3 ("tension handedness"). Fully proven.
2. **Two Tier-1 leftovers were CLOSED:**
   - LO3: the free-side distribution follows the DD1 series (r=3 removed, renormalised);
     shape exact, the prefactor 1.24 is pure normalisation.
   - LO4: tension-fraction sum (0.9027) + twin fraction (0.0931) = 0.9959 → 1.
3. **Two missing figures were GENERATED** (Newton convergence, classification grid).
   Note: the Newton figure was regenerated after a bug — earlier rough L(chi-3) zero
   values caused apparent non-convergence; true zeros computed to full precision fixed it.
4. **The synthesis and context docs were updated** to record all of the above.

## Steps to perform

### Step 1 — Inspect and locate
```
Read research/PRIME_RESEARCH_SYNTHESIS.md to understand the new results.
Check whether the repo already contains earlier versions of
PRIME_RESEARCH_CONTEXT.md, PRIME_RESEARCH_SYNTHESIS.md, or tier1_deep_dives.py
(they may have been committed in a prior session). Report what exists and
whether these incoming versions are newer/larger. Do not overwrite yet.
```

### Step 2 — Place the artefacts
```
Place the research artefacts in the shifted-prime-tension/ subproject:
- Move the two .md docs to shifted-prime-tension/docs/ (overwrite older copies
  if present — these are the authoritative updated versions).
- Move tier1_deep_dives.py and tier1_leftovers.py to shifted-prime-tension/src/.
- Move the two figures to shifted-prime-tension/figures/.
Show me the resulting directory tree before proceeding.
```

### Step 3 — Verify the scripts
```
From shifted-prime-tension/src/ (with the venv active, or install numpy+sympy),
run tier1_deep_dives.py and tier1_leftovers.py. Confirm:
- DD1 ratios all within ~1% of 1.0
- DD2: exactly-one-side=3 fraction = 1.000000, both = 0, neither = 0
- LO3: renormalised ratios all within ~1.5% of 1.0
- LO4: sum + twin ≈ 0.9959
Note: each takes ~90s at N=5e6. Report the key output lines.
```

### Step 4 — Update the subproject README
```
Update shifted-prime-tension/README.md: add a "Proven Tier-1 Results" section
listing DD1 (singular-series tension law), DD2 (exactly-one-maximum / handedness
theorem), LO3 (free-side distribution), and LO4 (sum check), each with a one-line
statement and pointing to tier1_deep_dives.py / tier1_leftovers.py. Add the two
new figures to any figures list. Show me the diff.
```

### Step 5 — Stage, review, commit (DO NOT push yet)
```
Stage all changes. Write a conventional commit message summarising:
the two proven Tier-1 deep dives, the two closed leftovers, the two new figures,
and the updated synthesis/context docs. Show me git diff --stat and the message.
Wait for my explicit approval before committing or pushing.
```

After I approve:
```
Commit and push to origin main.
```

## Guardrails (same as before)
- Do not alter any numerical constant or mathematical step in the scripts.
- The proven results are verified; if a run deviates, report it — do not "fix" the maths.
- Show diffs before any commit. I approve before push.
- The .md docs mark every claim ESTABLISHED / OPEN / SPECULATIVE — preserve that.
